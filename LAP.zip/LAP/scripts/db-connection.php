<?php
    $connection = mysqli_connect('localhost', 'root', '', 'immo') or die( "Verbindung zum SQL-Server nicht möglich" );
?>