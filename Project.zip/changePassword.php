<form action="scripts/passwd.php" method="POST">
  Current Password: <input type="password" name="oldpasswd"><br>
  New Password: <input type="password" name="newpasswd"><br>
  <input type="submit" value="Submit">
</form>